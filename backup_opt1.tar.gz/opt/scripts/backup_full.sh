#!/bin/bash


if [ "$1" == "-h" ]; then
   echo "Uso: $0 DIRECTORIO1 DIRECTORIO2"
   echo " DIRECTORIO1: Directorio al cual se le hace el backup"
   echo " DIRECTORIO2: Directorio donde se almacena el backup"
   exit 0
fi

DIRECTORIO1=$1
DIRECTORIO2=$2

if [ -z "$DIRECTORIO1" ] || [ -z "$DIRECTORIO2" ]; then
   echo "Error: Proporcione los directorios correctamente"
   exit 1
fi


if [ ! -d "$DIRECTORIO1" ]; then
  echo "Error: No existe el directorio proporcionado"
  exit 1
fi


if [ ! -d "$DIRECTORIO2" ]; then
  echo "Error: No existe el directorio donde se realizará el backup"
  exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE_DEL_BACKUP=$"$DIRECTORIO1"_backup_$FECHA.tar.gz



tar -czf "$DIRECTORIO2/$NOMBRE_DEL_BACKUP" -C "$DIRECTORIO1"

if [ $? -eq 0 ]; then
  echo "Backup realizado exitosamente"
  exit 1
fi

