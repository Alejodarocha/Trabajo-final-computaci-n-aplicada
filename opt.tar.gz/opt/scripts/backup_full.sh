#!/bin/bash
DIRECTORIO=$1
DIRECTORIO2=$2
FECHA=$(date +"%Ym%d")
NOMBRE_BACKUP=$(basename "DIRECTORIO")_bkp_$FECHA.tar.gz




echo "Haciendo el backup de $DIRECTORIO a $DIRECTORIO2"
tar -czf "$DIRECTORIO2/NOMBRE_BACKUP" -c "$(dirname "$DIRECTORIO")" "$(basename "$DIRECTORIO")"

if [[ $? -eq 0 ]]; then
  echo "Backup completado con éxito: $DIRECTORIO2/NOMBRE_BACKUP"
else 
  echo "Hubo un error"
  exit 1
fi

